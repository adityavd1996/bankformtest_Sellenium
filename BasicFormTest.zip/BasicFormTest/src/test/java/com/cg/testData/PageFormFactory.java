package com.cg.testData;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFormFactory {

	WebDriver web;
	
	// initiating Elements (always same at the beginning)
		public PageFormFactory(WebDriver webdriver) {
			this.web = webdriver;
			PageFactory.initElements(web, this);
		}

		@FindBy(name = "companyName")
		@CacheLookup
		WebElement companyName;

		@FindBy(xpath = "/html/body/center/form/input[2]")
		@CacheLookup
		WebElement username;
		
		@FindBy(xpath = "/html/body/center/form/input[3]")
		@CacheLookup
		WebElement city;
		
		@FindBy(xpath = "/html/body/center/form/input[4]")
		@CacheLookup
		WebElement password;
		
		@FindBy(xpath = "/html/body/center/form/input[5]")
		@CacheLookup
		WebElement gMale;
		
		@FindBy(xpath = "/html/body/center/form/input[6]")
		@CacheLookup
		WebElement gFemale;
		

		@FindBy(xpath = "/html/body/center/form/input[11]")
		@CacheLookup
		WebElement userNumber;
		
		@FindBy(xpath = "/html/body/center/form/input[13]")
		@CacheLookup
		WebElement mobile;
		
		@FindBy(xpath="/html/body/center/form/input[15]")
		@CacheLookup
		WebElement store;
		

		@FindBy(xpath="/html/body/center/form/input[16]")
		@CacheLookup
		WebElement clear;

		public WebDriver getWeb() {
			return web;
		}


		public void setWeb(WebDriver web) {
			this.web = web;
		}


		public WebElement getCompanyName() {
			return companyName;
		}


		public void setCompanyName(String companyName) {
			this.companyName.sendKeys(companyName);
		}


		public WebElement getUsername() {
			return username;
		}


		public void setUsername(String username) {
			this.username.sendKeys(username);
		}


		public WebElement getCity() {
			return city;
		}


		public void setCity(String city) {
			this.city.sendKeys(city);
		}


		public WebElement getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password.sendKeys(password);
		}


		public WebElement getgMale() {
			return gMale;
		}


		public void setgMale(WebElement gMale) {
			this.gMale = gMale;
		}


		public WebElement getgFemale() {
			return gFemale;
		}


		public void setgFemale(WebElement gFemale) {
			this.gFemale = gFemale;
		}


		public WebElement getMobile() {
			return mobile;
		}


		public void setMobile(String mobile) {
			this.mobile.sendKeys(mobile);
		}


		public WebElement getStore() {
			return store;
		}


		public void setStore() {
			store.click();
		}


		public WebElement getClear() {
			return clear;
		}


		public void setClear() {
			clear.click();
		}


		public void setUserNumber(String userNumber) {
			// TODO Auto-generated method stub
			this.userNumber.sendKeys(userNumber);
		}
		





}

