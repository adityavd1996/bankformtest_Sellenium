package com.cg.testData;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class FormStepDef {

	private PageFormFactory fact;
	private WebDriver driver;
	
	@Given("^User is on the Main Form Page$")
	public void user_is_on_the_Main_Form_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium Drivers\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFormFactory(driver);
		driver.get("C:\\Users\\addandap\\Desktop\\BasicForm.html");
		
		//throw new PendingException();
	}

	@When("^Company Name is empty$")
	public void company_Name_is_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    fact.setCompanyName("");
	    Thread.sleep(4000);
	    fact.setStore();
	    //throw new PendingException();
	}

	@Then("^Print Error Message$")
	public void print_Error_Message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
		//throw new PendingException();
	}

	/*@Given("^User has entered Valid Company Name$")
	public void user_has_entered_Valid_Company_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if(fact.companyName!=null)
		{
			
		}
		//throw new PendingException();
	}*/

	@When("^User Name is empty$")
	public void user_Name_is_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		fact.setCompanyName("CAPGEMINI");
		fact.setUsername("");
		Thread.sleep(4000);
		fact.setStore();
		//throw new PendingException();
	}

	/*@Given("^User has entered Valid User Name$")
	public void user_has_entered_Valid_User_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}
*/
	@When("^City is empty$")
	public void city_is_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		fact.setCompanyName("CAPGEMINI");
		fact.setUsername("Aditya");
		fact.setCity("");
		Thread.sleep(4000);
		fact.setStore();
		//throw new PendingException();
	}

	/*@Given("^User has entered Valid City Name$")
	public void user_has_entered_Valid_City_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}*/

	@When("^Password is empty$")
	public void password_is_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		fact.setCompanyName("CAPGEMINI");
		fact.setUsername("");
		fact.setCity("Gurgaon");
		fact.setPassword("");
		Thread.sleep(4000);
		fact.setStore();
		
		//throw new PendingException();
	}

	/*@Given("^User has given Gender$")
	public void user_has_given_Gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}*/

	@When("^Language is empty$")
	public void language_is_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		//throw new PendingException();
	}

	/*@Given("^User has chosen Languages Known$")
	public void user_has_chosen_Languages_Known() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
*/
	


	@When("^User Number is empty$")
	public void user_Number_is_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		fact.setUserNumber("");
		fact.setCompanyName("CAPGEMINI");
		fact.setUsername("Aditya");
		fact.setCity("Gurgaon");
		fact.setPassword("abcde");
		Thread.sleep(4000);
		fact.setStore();
		
		//throw new PendingException();
	}

/*
@Given("^User has entered all Valid Details$")
public void user_has_entered_all_Valid_Details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}*/

@When("^User Number clicks the Store button$")
public void user_Number_clicks_the_Store_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    System.out.println("Store button Clicked");
	//throw new PendingException();
}

@Then("^Value stored successfully$")
public void value_stored_successfully() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^User Number clicks the Clear button$")
public void user_Number_clicks_the_Clear_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^Value Reset takes place$")
public void value_Reset_takes_place() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^Print Error User Number Message$")
public void print_Error_User_Number_Message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
	// throw new PendingException();
}
@Then("^Print  Company Name Error Message$")
public void print_Company_Name_Error_Message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
}

@Then("^Print Username Error Message$")
public void print_Username_Error_Message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
}

@Then("^Print City value Error Message$")
public void print_City_value_Error_Message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
}

@Then("^Print Password Error Message$")
public void print_Password_Error_Message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.quit();
}

}
