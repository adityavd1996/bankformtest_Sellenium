$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cg/testData/basicform.feature");
formatter.feature({
  "line": 3,
  "name": "Basic Form Validation",
  "description": "       Check whether all the details are passed",
  "id": "basic-form-validation",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 7,
  "name": "Checking Company Name",
  "description": "",
  "id": "basic-form-validation;checking-company-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "Company Name is empty",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "Print  Company Name Error Message",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 3482491531,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.company_Name_is_empty()"
});
formatter.result({
  "duration": 4198336344,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.print_Company_Name_Error_Message()"
});
formatter.result({
  "duration": 17216604,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T513\u0027, ip: \u002710.219.34.227\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\addandap\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:64988}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: f9a161084930fee9ff0e12090b260920\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cg.testData.FormStepDef.print_Company_Name_Error_Message(FormStepDef.java:192)\r\n\tat ✽.Then Print  Company Name Error Message(com/cg/testData/basicform.feature:10)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 13,
  "name": "Checking user Name",
  "description": "",
  "id": "basic-form-validation;checking-user-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 15,
      "value": "#And  User has entered Valid Company Name"
    }
  ],
  "line": 16,
  "name": "User Name is empty",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "Print Username Error Message",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 2883851711,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.user_Name_is_empty()"
});
formatter.result({
  "duration": 4246477611,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.print_Username_Error_Message()"
});
formatter.result({
  "duration": 3753031,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T513\u0027, ip: \u002710.219.34.227\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\addandap\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:65001}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: 548df3f45489eee4bb7e0b479b551349\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cg.testData.FormStepDef.print_Username_Error_Message(FormStepDef.java:203)\r\n\tat ✽.Then Print Username Error Message(com/cg/testData/basicform.feature:17)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 19,
  "name": "Checking City",
  "description": "",
  "id": "basic-form-validation;checking-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 21,
      "value": "# And  User has entered Valid User Name"
    }
  ],
  "line": 22,
  "name": "City is empty",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "Print City value Error Message",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 2938569500,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.city_is_empty()"
});
formatter.result({
  "duration": 4381966581,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.print_City_value_Error_Message()"
});
formatter.result({
  "duration": 4525050,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T513\u0027, ip: \u002710.219.34.227\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\addandap\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:65013}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: 565cbe702423500e71a28cb0b57c4902\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cg.testData.FormStepDef.print_City_value_Error_Message(FormStepDef.java:214)\r\n\tat ✽.Then Print City value Error Message(com/cg/testData/basicform.feature:23)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 25,
  "name": "Checking User Password",
  "description": "",
  "id": "basic-form-validation;checking-user-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 26,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 27,
      "value": "#And  User has entered Valid City Name"
    }
  ],
  "line": 28,
  "name": "Password is empty",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "Print Password Error Message",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 3027962932,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.password_is_empty()"
});
formatter.result({
  "duration": 4405679305,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.print_Password_Error_Message()"
});
formatter.result({
  "duration": 4119351,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T513\u0027, ip: \u002710.219.34.227\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\addandap\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:65026}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: c73ab5ee79f90614a3430412144cd81c\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cg.testData.FormStepDef.print_Password_Error_Message(FormStepDef.java:225)\r\n\tat ✽.Then Print Password Error Message(com/cg/testData/basicform.feature:29)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "line": 31,
  "name": "Checking Gender",
  "description": "",
  "id": "basic-form-validation;checking-gender",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 32,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 33,
      "value": "# And  User has entered Valid User Password"
    }
  ],
  "line": 34,
  "name": "User enters the Gender \u003cinput\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "Print the Appropriate Message",
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "User User gives value Null",
  "rows": [
    {
      "cells": [
        "input"
      ],
      "line": 37
    },
    {
      "cells": [
        "M"
      ],
      "line": 38
    },
    {
      "cells": [
        "F"
      ],
      "line": 39
    }
  ],
  "keyword": "But "
});
formatter.scenario({
  "line": 42,
  "name": "Checking Languages Known",
  "description": "",
  "id": "basic-form-validation;checking-languages-known",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 43,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 44,
      "value": "# And  User has given Gender"
    }
  ],
  "line": 45,
  "name": "Language is empty",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "Print Error Message",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 3305899302,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.language_is_empty()"
});
formatter.result({
  "duration": 19280,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.print_Error_Message()"
});
formatter.result({
  "duration": 9389756,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T513\u0027, ip: \u002710.219.34.227\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\addandap\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:65039}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: 26688677e211bf95cec0a7c5e245b3a4\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cg.testData.FormStepDef.print_Error_Message(FormStepDef.java:45)\r\n\tat ✽.Then Print Error Message(com/cg/testData/basicform.feature:46)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 49,
  "name": "Checking User Number",
  "description": "",
  "id": "basic-form-validation;checking-user-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 51,
      "value": "# And  User has entered Country Name"
    }
  ],
  "line": 52,
  "name": "User Number is empty",
  "keyword": "When "
});
formatter.step({
  "line": 53,
  "name": "Print Error User Number Message",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 2825801770,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.user_Number_is_empty()"
});
formatter.result({
  "duration": 4458013350,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.print_Error_User_Number_Message()"
});
formatter.result({
  "duration": 9202699,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T513\u0027, ip: \u002710.219.34.227\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\addandap\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:65052}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: 3fbed172e0d78902676801db5b631ae6\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cg.testData.FormStepDef.print_Error_User_Number_Message(FormStepDef.java:181)\r\n\tat ✽.Then Print Error User Number Message(com/cg/testData/basicform.feature:53)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "line": 55,
  "name": "Checking Email",
  "description": "",
  "id": "basic-form-validation;checking-email",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 56,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 57,
      "value": "#And  User has entered Valid User Number"
    }
  ],
  "line": 58,
  "name": "User enters \u003cemail\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 59,
  "name": "Print the Validated value",
  "rows": [
    {
      "cells": [
        "email"
      ],
      "line": 60
    },
    {
      "cells": [
        "adigmail.com"
      ],
      "line": 61
    },
    {
      "cells": [
        "avd"
      ],
      "line": 62
    },
    {
      "cells": [
        "aditya@gmail.com"
      ],
      "line": 63
    },
    {
      "cells": [
        "abc@yahoo.com"
      ],
      "line": 64
    }
  ],
  "keyword": "Then "
});
formatter.scenarioOutline({
  "line": 67,
  "name": "Checking Mobile Number",
  "description": "",
  "id": "basic-form-validation;checking-mobile-number",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 68,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 69,
      "value": "# And  User has entered Valid Email"
    }
  ],
  "line": 70,
  "name": "User enters Mobile Number \u003cmobile\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 71,
  "name": "Print the Message",
  "rows": [
    {
      "cells": [
        "mobile"
      ],
      "line": 72
    },
    {
      "cells": [
        "99992222"
      ],
      "line": 73
    },
    {
      "cells": [
        "abcvde"
      ],
      "line": 74
    },
    {
      "cells": [
        "9997878986"
      ],
      "line": 75
    },
    {
      "cells": [
        "2223334445"
      ],
      "line": 76
    },
    {
      "cells": [
        "0987688"
      ],
      "line": 77
    },
    {
      "cells": [
        "8769876665"
      ],
      "line": 78
    }
  ],
  "keyword": "Then "
});
formatter.scenario({
  "line": 81,
  "name": "Clicking Store Button",
  "description": "",
  "id": "basic-form-validation;clicking-store-button",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 82,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 83,
      "value": "# And  User has entered all Valid Details"
    }
  ],
  "line": 84,
  "name": "User Number clicks the Store button",
  "keyword": "When "
});
formatter.step({
  "line": 85,
  "name": "Value stored successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 2922019490,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.user_Number_clicks_the_Store_button()"
});
formatter.result({
  "duration": 88196,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.value_stored_successfully()"
});
formatter.result({
  "duration": 909851,
  "error_message": "cucumber.api.PendingException: TODO: implement me\r\n\tat com.cg.testData.FormStepDef.value_stored_successfully(FormStepDef.java:163)\r\n\tat ✽.Then Value stored successfully(com/cg/testData/basicform.feature:85)\r\n",
  "status": "pending"
});
formatter.scenario({
  "line": 88,
  "name": "Clicking Clear Button",
  "description": "",
  "id": "basic-form-validation;clicking-clear-button",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 89,
  "name": "User is on the Main Form Page",
  "keyword": "Given "
});
formatter.step({
  "line": 90,
  "name": "User Number clicks the Clear button",
  "keyword": "When "
});
formatter.step({
  "line": 91,
  "name": "Value Reset takes place",
  "keyword": "Then "
});
formatter.match({
  "location": "FormStepDef.user_is_on_the_Main_Form_Page()"
});
formatter.result({
  "duration": 3125255818,
  "status": "passed"
});
formatter.match({
  "location": "FormStepDef.user_Number_clicks_the_Clear_button()"
});
formatter.result({
  "duration": 137010,
  "error_message": "cucumber.api.PendingException: TODO: implement me\r\n\tat com.cg.testData.FormStepDef.user_Number_clicks_the_Clear_button(FormStepDef.java:169)\r\n\tat ✽.When User Number clicks the Clear button(com/cg/testData/basicform.feature:90)\r\n",
  "status": "pending"
});
formatter.match({
  "location": "FormStepDef.value_Reset_takes_place()"
});
formatter.result({
  "status": "skipped"
});
});